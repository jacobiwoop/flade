<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../../config/config.php';
require_once '../../classes/Chat.php';

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Non authentifié']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['conversation_id'])) {
    echo json_encode(['success' => false, 'message' => 'Données manquantes']);
    exit;
}

$conversation_id = intval($input['conversation_id']);
$content = isset($input['content']) ? trim($input['content']) : '';
$reply_to_message_id = isset($input['reply_to_message_id']) ? intval($input['reply_to_message_id']) : null;
$image_path = isset($input['image_path']) ? $input['image_path'] : null;
$voice_path = isset($input['voice_path']) ? $input['voice_path'] : null;

// Vérifier qu'il y a au moins du contenu, une image ou un message vocal
if (empty($content) && empty($image_path) && empty($voice_path)) {
    echo json_encode(['success' => false, 'message' => 'Message vide']);
    exit;
}

if (!empty($content) && strlen($content) > 1000) {
    echo json_encode(['success' => false, 'message' => 'Message trop long (maximum 1000 caractères)']);
    exit;
}

try {
    $chat = new Chat();
    
    // Vérifier que l'utilisateur fait partie de la conversation
    if (!$chat->isUserInConversation($_SESSION['user_id'], $conversation_id)) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Accès non autorisé']);
        exit;
    }
    
    $message = $chat->sendMessage(
        $conversation_id,
        $_SESSION['user_id'],
        $content,
        $reply_to_message_id,
        $image_path,
        $voice_path
    );
    
    if ($message) {
        echo json_encode([
            'success' => true,
            'message' => $message
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Erreur lors de l\'envoi du message']);
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Erreur: ' . $e->getMessage()
    ]);
}
?>
