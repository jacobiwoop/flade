<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../../config/config.php';
require_once '../../classes/Chat.php';

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Non authentifié']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['name']) || !isset($input['participants'])) {
    echo json_encode(['success' => false, 'message' => 'Données manquantes']);
    exit;
}

$name = sanitize($input['name']);
$participants = $input['participants'];

// Ajouter l'utilisateur actuel aux participants
if (!in_array($_SESSION['user_id'], $participants)) {
    $participants[] = $_SESSION['user_id'];
}

if (empty($name)) {
    echo json_encode(['success' => false, 'message' => 'Le nom de la conversation est requis']);
    exit;
}

if (count($participants) < 2) {
    echo json_encode(['success' => false, 'message' => 'Au moins 2 participants sont requis']);
    exit;
}

try {
    $chat = new Chat();
    $conversation_id = $chat->createConversation($name, $participants);
    
    if ($conversation_id) {
        echo json_encode([
            'success' => true,
            'conversation_id' => $conversation_id,
            'message' => 'Conversation créée avec succès'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Erreur lors de la création de la conversation']);
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Erreur: ' . $e->getMessage()
    ]);
}
?>
