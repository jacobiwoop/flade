<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../../config/config.php';
require_once '../../classes/Chat.php';

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Non authentifié']);
    exit;
}

$conversation_id = isset($_GET['conversation_id']) ? intval($_GET['conversation_id']) : 0;
$last_message_id = isset($_GET['last_message_id']) ? intval($_GET['last_message_id']) : 0;

if ($conversation_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'ID de conversation invalide']);
    exit;
}

try {
    $chat = new Chat();
    
    // Vérifier que l'utilisateur fait partie de la conversation
    if (!$chat->isUserInConversation($_SESSION['user_id'], $conversation_id)) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Accès non autorisé']);
        exit;
    }
    
    if ($last_message_id > 0) {
        // Récupérer seulement les nouveaux messages
        $messages = $chat->getNewMessages($conversation_id, $last_message_id);
        echo json_encode([
            'success' => true,
            'messages' => $messages
        ]);
    } else {
        // Récupérer tous les messages et les infos de conversation
        $messages = $chat->getConversationMessages($conversation_id, $_SESSION['user_id']);
        $conversation_info = $chat->getConversationInfo($conversation_id);
        $other_user = $chat->getOtherUserInConversation($conversation_id, $_SESSION['user_id']);
        
        // Marquer la conversation comme lue
        $chat->markConversationAsRead($conversation_id, $_SESSION['user_id']);
        
        echo json_encode([
            'success' => true,
            'messages' => $messages,
            'conversation' => [
                'id' => $conversation_info['id'],
                'name' => $conversation_info['name'],
                'display_name' => $other_user ? $other_user['pseudo'] : $conversation_info['name'],
                'other_user_photo' => $other_user ? 'uploads/profiles/' . $other_user['profile_photo'] : null,
                'other_user_online' => $other_user ? $other_user['is_online'] : false
            ]
        ]);
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Erreur lors du chargement des messages: ' . $e->getMessage()
    ]);
}
?>
