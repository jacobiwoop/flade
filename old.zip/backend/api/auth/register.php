<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../../config/config.php';
require_once '../../auth/User.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['pseudo']) || !isset($input['email']) || !isset($input['password'])) {
    echo json_encode(['success' => false, 'message' => 'Données manquantes']);
    exit;
}

$pseudo = sanitize($input['pseudo']);
$email = sanitize($input['email']);
$password = $input['password'];
$confirm_password = $input['confirm_password'] ?? '';

// Validation
$errors = [];

if (empty($pseudo)) {
    $errors[] = 'Le pseudo est requis';
} elseif (strlen($pseudo) < 3) {
    $errors[] = 'Le pseudo doit contenir au moins 3 caractères';
}

if (empty($email)) {
    $errors[] = 'L\'email est requis';
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Format d\'email invalide';
}

if (empty($password)) {
    $errors[] = 'Le mot de passe est requis';
} elseif (strlen($password) < 6) {
    $errors[] = 'Le mot de passe doit contenir au moins 6 caractères';
}

if ($password !== $confirm_password) {
    $errors[] = 'Les mots de passe ne correspondent pas';
}

if (!empty($errors)) {
    echo json_encode(['success' => false, 'message' => implode(', ', $errors)]);
    exit;
}

$user = new User();
$result = $user->register($pseudo, $email, $password);

echo json_encode($result);
?>
