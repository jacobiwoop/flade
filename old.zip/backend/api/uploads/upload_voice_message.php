<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../../config/config.php';

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Non authentifié']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
    exit;
}

if (!isset($_FILES['voice'])) {
    echo json_encode(['success' => false, 'message' => 'Aucun fichier vocal fourni']);
    exit;
}

$file = $_FILES['voice'];

// Validation du fichier
$allowedTypes = ['audio/wav', 'audio/mpeg', 'audio/mp3', 'audio/webm'];
if (!in_array($file['type'], $allowedTypes)) {
    echo
