<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../config/config.php';
require_once '../config/database.php';

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Non authentifié']);
    exit;
}

$search = isset($_GET['search']) ? trim($_GET['search']) : '';

try {
    $database = new Database();
    $conn = $database->getConnection();
    
    $query = "SELECT id, pseudo, profile_photo, is_online FROM users WHERE id != ?";
    $params = [$_SESSION['user_id']];
    
    if (!empty($search)) {
        $query .= " AND pseudo LIKE ?";
        $params[] = '%' . $search . '%';
    }
    
    $query .= " ORDER BY is_online DESC, pseudo ASC LIMIT 20";
    
    $stmt = $conn->prepare($query);
    $stmt->execute($params);
    $users = $stmt->fetchAll();
    
    echo json_encode([
        'success' => true,
        'users' => $users
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Erreur: ' . $e->getMessage()
    ]);
}
?>
