<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../config/config.php';
require_once '../config/database.php';

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Non authentifié']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'ID utilisateur manquant']);
    exit;
}

$other_user_id = intval($input['user_id']);
$current_user_id = $_SESSION['user_id'];

if ($other_user_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'ID utilisateur invalide']);
    exit;
}

if ($other_user_id === $current_user_id) {
    echo json_encode(['success' => false, 'message' => 'Vous ne pouvez pas créer une conversation avec vous-même']);
    exit;
}

try {
    $database = new Database();
    $conn = $database->getConnection();
    
    // Vérifier si une conversation directe existe déjà entre ces deux utilisateurs
    $query = "
        SELECT c.id 
        FROM conversations c
        INNER JOIN conversation_participants cp1 ON c.id = cp1.conversation_id
        INNER JOIN conversation_participants cp2 ON c.id = cp2.conversation_id
        WHERE cp1.user_id = ? AND cp2.user_id = ?
        AND (
            SELECT COUNT(*) 
            FROM conversation_participants cp3 
            WHERE cp3.conversation_id = c.id
        ) = 2
    ";
    
    $stmt = $conn->prepare($query);
    $stmt->execute([$current_user_id, $other_user_id]);
    $existing_conversation = $stmt->fetch();
    
    if ($existing_conversation) {
        echo json_encode([
            'success' => true,
            'conversation_id' => $existing_conversation['id'],
            'message' => 'Conversation existante trouvée'
        ]);
        exit;
    }
    
    // Créer une nouvelle conversation
    $conn->beginTransaction();
    
    // Insérer la conversation
    $query = "INSERT INTO conversations (name) VALUES (NULL)";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $conversation_id = $conn->lastInsertId();
    
    // Ajouter les participants
    $query = "INSERT INTO conversation_participants (conversation_id, user_id) VALUES (?, ?)";
    $stmt = $conn->prepare($query);
    
    $stmt->execute([$conversation_id, $current_user_id]);
    $stmt->execute([$conversation_id, $other_user_id]);
    
    $conn->commit();
    
    echo json_encode([
        'success' => true,
        'conversation_id' => $conversation_id,
        'message' => 'Conversation créée avec succès'
    ]);
    
} catch (Exception $e) {
    if (isset($conn)) {
        $conn->rollBack();
    }
    echo json_encode([
        'success' => false,
        'message' => 'Erreur: ' . $e->getMessage()
    ]);
}
?>
