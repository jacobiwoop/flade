// Gestion du dashboard
class DashboardManager {
  constructor() {
    this.baseUrl = "/backend/api"
    this.selectedUserId = null
    this.conversations = []
    this.init()
  }

  async init() {
    // Vérifier l'authentification
    const user = await window.authManager.checkAuth()
    if (!user) return

    // Afficher les informations utilisateur
    this.displayUserInfo(user)

    // Charger les conversations avec effet de loading
    this.showLoadingEffect()
    setTimeout(() => this.loadConversations(), 800)
  }

  displayUserInfo(user) {
    const userAvatar = document.getElementById("userAvatar")
    const welcomeMessage = document.getElementById("welcomeMessage")

    if (userAvatar) {
      userAvatar.textContent = user.pseudo.substring(0, 2).toUpperCase()
    }

    if (welcomeMessage) {
      welcomeMessage.textContent = `Bonjour, ${user.pseudo}`
    }
  }

  showLoadingEffect() {
    // Afficher le skeleton loader pendant un court moment pour l'effet visuel
    setTimeout(() => {
      document.getElementById("conversationsLoader").style.display = "none"
      document.getElementById("skeletonLoader").classList.remove("hidden")
    }, 500)
  }

  async loadConversations() {
    try {
      const response = await fetch(`${this.baseUrl}/chat/get_conversations.php`)
      const data = await response.json()

      // Masquer les loaders
      document.getElementById("skeletonLoader").classList.add("hidden")

      if (data.success) {
        this.conversations = data.conversations
        this.displayConversations(this.conversations)
      } else {
        this.showError("Erreur lors du chargement des conversations: " + data.message)
      }
    } catch (error) {
      console.error("Erreur:", error)
      document.getElementById("skeletonLoader").classList.add("hidden")
      this.showError("Erreur de connexion")
    }
  }

  displayConversations(conversations) {
    const container = document.getElementById("conversationsContent")

    if (conversations.length === 0) {
      container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-comments"></i>
                    <h3 class="text-lg font-semibold mb-2">Aucune conversation</h3>
                    <p class="mb-4">Commencez une nouvelle conversation en cliquant sur le bouton +</p>
                </div>
            `
      return
    }

    container.innerHTML = conversations
      .map((conv) => {
        const avatarColors = ["avatar-blue", "avatar-green", "avatar-purple"]
        const avatarColor = avatarColors[conv.id % avatarColors.length]

        return `
                <div class="conversation-item" onclick="openConversation(${conv.id})">
                    ${conv.unread_count > 0 ? `<div class="unread-badge">${conv.unread_count}</div>` : ""}
                    
                    <div class="flex items-center space-x-3">
                        <div class="avatar ${avatarColor} text-white">
                            ${
                              conv.other_user_photo
                                ? `<img src="/backend/${conv.other_user_photo}" alt="Photo de profil">`
                                : conv.display_name.substring(0, 2).toUpperCase()
                            }
                        </div>
                        
                        <div class="flex-1 min-w-0">
                            <div class="flex items-center justify-between">
                                <h3 class="text-white font-medium truncate">
                                    ${conv.display_name}
                                </h3>
                                <span class="text-gray-400 text-xs">
                                    ${this.formatTime(conv.last_message_time)}
                                </span>
                            </div>
                            
                            <p class="text-gray-400 text-sm truncate">
                                ${conv.last_message}
                            </p>
                        </div>
                    </div>
                </div>
            `
      })
      .join("")
  }

  async loadUsers() {
    try {
      const response = await fetch(`${this.baseUrl}/get_users.php`)
      const data = await response.json()

      if (data.success) {
        this.displayUsers(data.users)
      }
    } catch (error) {
      console.error("Erreur chargement utilisateurs:", error)
    }
  }

  displayUsers(users) {
    const container = document.getElementById("usersList")

    if (users.length === 0) {
      container.innerHTML = '<p class="text-gray-400 text-center py-4">Aucun utilisateur trouvé</p>'
      return
    }

    container.innerHTML = users
      .map(
        (user) => `
            <div class="user-item" onclick="selectUser(${user.id}, '${user.pseudo}')">
                <div class="flex items-center space-x-3">
                    <div class="avatar avatar-blue text-white">
                        ${
                          user.profile_photo
                            ? `<img src="/backend/uploads/profiles/${user.profile_photo}" alt="Photo de profil">`
                            : user.pseudo.substring(0, 2).toUpperCase()
                        }
                    </div>
                    <div>
                        <h4 class="text-white font-medium">${user.pseudo}</h4>
                        <p class="text-gray-400 text-sm">
                            ${user.is_online ? "En ligne" : "Hors ligne"}
                        </p>
                    </div>
                </div>
            </div>
        `,
      )
      .join("")
  }

  async searchUsers() {
    clearTimeout(this.searchTimeout)
    this.searchTimeout = setTimeout(async () => {
      const query = document.getElementById("userSearch").value

      try {
        const response = await fetch(`${this.baseUrl}/get_users.php?search=${encodeURIComponent(query)}`)
        const data = await response.json()

        if (data.success) {
          this.displayUsers(data.users)
        }
      } catch (error) {
        console.error("Erreur recherche:", error)
      }
    }, 300)
  }

  async createDirectConversation() {
    if (!this.selectedUserId) return

    try {
      const response = await fetch(`${this.baseUrl}/create_direct_conversation.php`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          user_id: this.selectedUserId,
        }),
      })

      const data = await response.json()

      if (data.success) {
        this.closeNewConversationModal()
        window.location.href = `conversation.html?id=${data.conversation_id}`
      } else {
        alert("Erreur: " + data.message)
      }
    } catch (error) {
      console.error("Erreur création conversation:", error)
      alert("Erreur lors de la création de la conversation")
    }
  }

  openNewConversationModal() {
    document.getElementById("newConversationModal").style.display = "flex"
    this.loadUsers()
  }

  closeNewConversationModal() {
    document.getElementById("newConversationModal").style.display = "none"
    this.selectedUserId = null
    document.getElementById("userSearch").value = ""
    document.getElementById("createConversationBtn").disabled = true
  }

  selectUser(userId, pseudo) {
    this.selectedUserId = userId

    // Mettre à jour l'affichage
    document.querySelectorAll(".user-item").forEach((item) => {
      item.classList.remove("selected")
    })
    event.currentTarget.classList.add("selected")

    document.getElementById("createConversationBtn").disabled = false
  }

  formatTime(timestamp) {
    const date = new Date(timestamp)
    const now = new Date()
    const diff = now - date

    if (diff < 60000) {
      // Moins d'une minute
      return "À l'instant"
    } else if (diff < 3600000) {
      // Moins d'une heure
      return Math.floor(diff / 60000) + "m"
    } else if (diff < 86400000) {
      // Moins d'un jour
      return Math.floor(diff / 3600000) + "h"
    } else if (diff < 604800000) {
      // Moins d'une semaine
      return Math.floor(diff / 86400000) + "j"
    } else {
      return date.toLocaleDateString("fr-FR", {
        day: "2-digit",
        month: "2-digit",
      })
    }
  }

  showError(message) {
    const container = document.getElementById("conversationsContent")
    container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-exclamation-triangle text-red-400"></i>
                <h3 class="text-lg font-semibold mb-2 text-red-400">Erreur</h3>
                <p class="mb-4">${message}</p>
                <button class="btn btn-primary" onclick="dashboardManager.loadConversations()">
                    Réessayer
                </button>
            </div>
        `
  }
}

// Fonctions globales
function openConversation(conversationId) {
  window.location.href = `conversation.html?id=${conversationId}`
}

function openNewConversationModal() {
  window.dashboardManager.openNewConversationModal()
}

function closeNewConversationModal() {
  window.dashboardManager.closeNewConversationModal()
}

function selectUser(userId, pseudo) {
  window.dashboardManager.selectUser(userId, pseudo)
}

function searchUsers() {
  window.dashboardManager.searchUsers()
}

function createDirectConversation() {
  window.dashboardManager.createDirectConversation()
}

// Initialiser le gestionnaire du dashboard
window.dashboardManager = new DashboardManager()

// Actualiser les conversations périodiquement
setInterval(() => {
  if (window.dashboardManager) {
    window.dashboardManager.loadConversations()
  }
}, 30000) // Toutes les 30 secondes
