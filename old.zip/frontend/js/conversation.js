// Gestion des conversations
class ConversationManager {
  constructor() {
    this.baseUrl = "/backend/api"
    this.websocketUrl = "ws://localhost:8080"
    this.conversationId = null
    this.userId = null
    this.userPseudo = null
    this.websocket = null
    this.isConnected = false
    this.isAuthenticated = false
    this.replyToMessageId = null
    this.lastMessageId = 0
    this.init()
  }

  async init() {
    // Vérifier l'authentification
    const user = await window.authManager.checkAuth()
    if (!user) return

    this.userId = user.id
    this.userPseudo = user.pseudo

    // Récupérer l'ID de conversation depuis l'URL
    const urlParams = new URLSearchParams(window.location.search)
    this.conversationId = Number.parseInt(urlParams.get("id"))

    if (!this.conversationId) {
      window.location.href = "dashboard.html"
      return
    }

    // Charger les données de la conversation
    await this.loadConversationData()

    // Configurer les événements
    this.setupEventListeners()

    // Connecter WebSocket
    this.connectWebSocket()

    // Polling de secours
    setInterval(() => this.pollForNewMessages(), 5000)
  }

  async loadConversationData() {
    try {
      // Charger les informations de la conversation
      const response = await fetch(`${this.baseUrl}/chat/get_messages.php?conversation_id=${this.conversationId}`)
      const data = await response.json()

      if (data.success) {
        this.displayConversationInfo(data.conversation)
        this.displayMessages(data.messages)

        if (data.messages.length > 0) {
          this.lastMessageId = data.messages[data.messages.length - 1].id
        }
      } else {
        console.error("Erreur chargement conversation:", data.message)
        window.location.href = "dashboard.html"
      }
    } catch (error) {
      console.error("Erreur:", error)
      window.location.href = "dashboard.html"
    }
  }

  displayConversationInfo(conversation) {
    const conversationName = document.getElementById("conversationName")
    const conversationAvatar = document.getElementById("conversationAvatar")
    const conversationStatus = document.getElementById("conversationStatus")
    const onlineDot = document.getElementById("onlineDot")

    if (conversationName) {
      conversationName.textContent = conversation.display_name || conversation.name || "Conversation"
    }

    if (conversationAvatar) {
      if (conversation.other_user_photo) {
        conversationAvatar.innerHTML = `<img src="/backend/${conversation.other_user_photo}" alt="Photo de profil">`
      } else {
        conversationAvatar.textContent = (conversation.display_name || conversation.name || "C")
          .substring(0, 2)
          .toUpperCase()
      }
    }

    if (conversationStatus && onlineDot) {
      if (conversation.other_user_online) {
        conversationStatus.textContent = "En ligne"
        conversationStatus.className = "text-sm text-green-400"
        onlineDot.classList.remove("hidden")
      } else {
        conversationStatus.textContent = "Hors ligne"
        conversationStatus.className = "text-sm text-gray-400"
        onlineDot.classList.add("hidden")
      }
    }
  }

  displayMessages(messages) {
    const container = document.getElementById("messagesContent")

    if (messages.length === 0) {
      container.innerHTML = `
                <div class="text-center text-gray-400 py-8">
                    <i class="fas fa-comments text-4xl mb-4 opacity-50"></i>
                    <p class="text-lg">Aucun message dans cette conversation.</p>
                    <p class="text-sm">Soyez le premier à envoyer un message !</p>
                </div>
            `
      return
    }

    container.innerHTML = messages.map((message) => this.createMessageHTML(message)).join("")
    this.scrollToBottom()
  }

  createMessageHTML(message) {
    if (message.is_deleted) {
      return `
                <div class="message deleted ${message.sender_id == this.userId ? "sent" : "received"}">
                    <div class="message-bubble">
                        <div><i class="fas fa-trash mr-2"></i>Ce message a été supprimé</div>
                        <div class="message-time">
                            ${this.formatTime(message.created_at)}
                        </div>
                    </div>
                </div>
            `
    }

    const isOwnMessage = message.sender_id == this.userId
    let messageContent = ""

    // Message de réponse
    if (message.reply_to_message_id) {
      messageContent += `
                <div class="message-reply">
                    <div class="reply-author">${message.reply_user_pseudo || "Utilisateur supprimé"}</div>
                    <div class="reply-content">
                        ${
                          message.reply_image_path
                            ? '<div class="reply-image-indicator"><i class="fas fa-image"></i><span>Image partagée</span></div>'
                            : message.reply_voice_path
                              ? '<div class="reply-image-indicator"><i class="fas fa-microphone"></i><span>Message vocal</span></div>'
                              : this.escapeHtml(message.reply_content || "Message supprimé")
                        }
                    </div>
                </div>
            `
    }

    // Message vocal
    if (message.voice_path) {
      messageContent += `
                <div class="voice-message mb-2">
                    <button onclick="playVoiceMessage('/backend/${message.voice_path}', this)" class="voice-play-button">
                        <i class="fas fa-play"></i>
                    </button>
                    <div class="voice-waveform">
                        <div class="voice-progress" style="width: 0%"></div>
                    </div>
                    <div class="voice-duration">
                        ${this.formatVoiceDuration(message.voice_duration || 0)}
                    </div>
                </div>
            `
    }

    // Image
    if (message.image_path) {
      messageContent += `
                <div class="mb-2">
                    <img src="/backend/${message.image_path}" alt="Image" class="message-image" 
                         onclick="openImageModal('/backend/${message.image_path}')">
                </div>
            `
    }

    // Contenu texte
    if (message.content) {
      messageContent += `<div>${this.escapeHtml(message.content).replace(/\n/g, "<br>")}</div>`
    }

    // Actions de message
    const actions = isOwnMessage
      ? `<button class="message-action-btn" onclick="replyToMessage(${message.id}, '${this.escapeHtml(message.sender_pseudo)}', '${this.escapeHtml(message.content || "Message")}')">
                <i class="fas fa-reply"></i>
            </button>
            <button class="message-action-btn" onclick="deleteMessage(${message.id})">
                <i class="fas fa-trash"></i>
            </button>`
      : `<button class="message-action-btn" onclick="replyToMessage(${message.id}, '${this.escapeHtml(message.sender_pseudo)}', '${this.escapeHtml(message.content || "Message")}')">
                <i class="fas fa-reply"></i>
            </button>`

    return `
            <div class="message ${isOwnMessage ? "sent" : "received"}" data-message-id="${message.id}">
                <div class="message-bubble" style="position: relative;">
                    <div class="message-actions">
                        ${actions}
                    </div>
                    ${messageContent}
                    <div class="message-time">
                        ${this.formatTime(message.created_at)}
                        ${isOwnMessage ? '<i class="fas fa-check message-status read"></i>' : ""}
                    </div>
                </div>
            </div>
        `
  }

  setupEventListeners() {
    // Formulaire de message
    const messageForm = document.getElementById("messageForm")
    if (messageForm) {
      messageForm.addEventListener("submit", (e) => this.sendMessage(e))
    }

    // Input de message
    const messageInput = document.getElementById("messageInput")
    if (messageInput) {
      messageInput.addEventListener("input", () => this.handleTyping())
      messageInput.addEventListener("keypress", (e) => {
        if (e.key === "Enter" && !e.shiftKey) {
          e.preventDefault()
          this.sendMessage(e)
        }
      })
      messageInput.focus()
    }

    // Upload d'image
    this.setupImageUpload()
  }

  setupImageUpload() {
    const uploadArea = document.getElementById("imageUploadArea")
    const imageInput = document.getElementById("imageInput")

    if (uploadArea && imageInput) {
      uploadArea.addEventListener("click", () => imageInput.click())

      uploadArea.addEventListener("dragover", (e) => {
        e.preventDefault()
        uploadArea.classList.add("dragover")
      })

      uploadArea.addEventListener("dragleave", (e) => {
        e.preventDefault()
        uploadArea.classList.remove("dragover")
      })

      uploadArea.addEventListener("drop", (e) => {
        e.preventDefault()
        uploadArea.classList.remove("dragover")
        const files = e.dataTransfer.files
        if (files.length > 0) {
          this.handleImageUpload(files[0])
        }
      })

      imageInput.addEventListener("change", (e) => {
        if (e.target.files.length > 0) {
          this.handleImageUpload(e.target.files[0])
        }
      })
    }
  }

  connectWebSocket() {
    try {
      this.websocket = new WebSocket(this.websocketUrl)

      this.websocket.onopen = () => {
        console.log("WebSocket connecté")
        this.isConnected = true
        this.updateConnectionStatus("connected", "Connecté")
        this.authenticate()
      }

      this.websocket.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data)
          this.handleWebSocketMessage(data)
        } catch (e) {
          console.error("Erreur parsing message WebSocket:", e)
        }
      }

      this.websocket.onclose = () => {
        console.log("WebSocket déconnecté")
        this.isConnected = false
        this.isAuthenticated = false
        this.updateConnectionStatus("disconnected", "Déconnecté")
      }

      this.websocket.onerror = (error) => {
        console.error("Erreur WebSocket:", error)
        this.updateConnectionStatus("disconnected", "Erreur de connexion")
      }
    } catch (e) {
      console.error("Erreur création WebSocket:", e)
      this.updateConnectionStatus("disconnected", "Erreur de connexion")
    }
  }

  authenticate() {
    if (!this.isConnected || this.isAuthenticated) return

    const authMessage = {
      type: "auth",
      user_id: this.userId,
      conversation_id: this.conversationId,
    }

    try {
      this.websocket.send(JSON.stringify(authMessage))
    } catch (e) {
      console.error("Erreur envoi authentification:", e)
    }
  }

  handleWebSocketMessage(data) {
    console.log("Message WebSocket reçu:", data)

    switch (data.type) {
      case "success":
        if (data.message === "Authentification réussie") {
          this.isAuthenticated = true
          this.updateConnectionStatus("connected", "Connecté")
        }
        break

      case "new_message":
        if (data.message) {
          this.addMessageToUI(data.message)
        }
        break

      case "typing":
        this.handleTypingIndicator(data)
        break

      case "error":
        console.error("Erreur WebSocket:", data.message)
        break
    }
  }

  addMessageToUI(message) {
    const existingMessage = document.querySelector(`[data-message-id="${message.id}"]`)
    if (existingMessage) return

    const messagesContainer = document.getElementById("messagesContent")
    const typingIndicator = document.getElementById("typingIndicator")

    const messageHTML = this.createMessageHTML(message)
    const messageElement = document.createElement("div")
    messageElement.innerHTML = messageHTML

    messagesContainer.insertBefore(messageElement.firstElementChild, typingIndicator)

    if (message.id) {
      this.lastMessageId = Math.max(this.lastMessageId, message.id)
    }

    this.scrollToBottom()

    // Notification pour les messages des autres
    if (message.sender_id != this.userId) {
      if (navigator.vibrate) {
        navigator.vibrate(200)
      }
    }
  }

  async sendMessage(e) {
    e.preventDefault()

    const messageInput = document.getElementById("messageInput")
    const content = messageInput.value.trim()

    if (!content) return

    if (this.isConnected && this.isAuthenticated) {
      try {
        this.websocket.send(
          JSON.stringify({
            type: "message",
            content: content,
            reply_to_message_id: this.replyToMessageId,
          }),
        )

        messageInput.value = ""
        this.cancelReply()
      } catch (e) {
        console.error("Erreur envoi WebSocket:", e)
        this.sendMessageViaAPI(content)
      }
    } else {
      this.sendMessageViaAPI(content)
    }
  }

  async sendMessageViaAPI(content, imagePath = null, voicePath = null) {
    try {
      const response = await fetch(`${this.baseUrl}/chat/send_message.php`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          conversation_id: this.conversationId,
          content: content,
          reply_to_message_id: this.replyToMessageId,
          image_path: imagePath,
          voice_path: voicePath,
        }),
      })

      const data = await response.json()

      if (data.success && data.message) {
        this.addMessageToUI(data.message)
        document.getElementById("messageInput").value = ""
        this.cancelReply()
      } else {
        alert("Erreur: " + (data.message || "Erreur inconnue"))
      }
    } catch (error) {
      console.error("Erreur envoi message API:", error)
      alert("Erreur lors de l'envoi du message")
    }
  }

  handleTyping() {
    if (this.isConnected && this.isAuthenticated) {
      clearTimeout(this.typingTimeout)

      if (!this.isTyping) {
        this.isTyping = true
        this.sendTypingStatus(true)
      }

      this.typingTimeout = setTimeout(() => {
        this.isTyping = false
        this.sendTypingStatus(false)
      }, 1000)
    }
  }

  sendTypingStatus(typing) {
    if (this.isConnected && this.isAuthenticated) {
      try {
        this.websocket.send(
          JSON.stringify({
            type: "typing",
            is_typing: typing,
          }),
        )
      } catch (e) {
        console.error("Erreur envoi statut frappe:", e)
      }
    }
  }

  handleTypingIndicator(data) {
    const typingIndicator = document.getElementById("typingIndicator")
    const typingUser = document.getElementById("typingUser")

    if (data.is_typing && data.user_id != this.userId) {
      typingUser.textContent = `Utilisateur ${data.user_id}`
      typingIndicator.classList.add("show")

      clearTimeout(this.typingTimeout)
      this.typingTimeout = setTimeout(() => {
        typingIndicator.classList.remove("show")
      }, 3000)
    } else if (data.user_id != this.userId) {
      typingIndicator.classList.remove("show")
    }
  }

  async pollForNewMessages() {
    if (this.isConnected && this.isAuthenticated) return

    try {
      const response = await fetch(
        `${this.baseUrl}/chat/get_messages.php?conversation_id=${this.conversationId}&last_message_id=${this.lastMessageId}`,
      )
      const data = await response.json()

      if (data.success && data.messages && data.messages.length > 0) {
        data.messages.forEach((message) => {
          this.addMessageToUI(message)
        })
      }
    } catch (error) {
      console.error("Erreur polling messages:", error)
    }
  }

  updateConnectionStatus(status, statusText) {
    const statusDot = document.querySelector(".status-dot")
    const statusTextElement = document.querySelector("#connectionStatus span")

    if (statusDot) {
      statusDot.className = `status-dot ${status}`
    }

    if (statusTextElement) {
      statusTextElement.textContent = statusText
    }
  }

  scrollToBottom() {
    setTimeout(() => {
      const messagesContainer = document.getElementById("messagesContainer")
      if (messagesContainer) {
        messagesContainer.scrollTop = messagesContainer.scrollHeight
      }
    }, 100)
  }

  formatTime(timestamp) {
    const date = new Date(timestamp)
    return date.toLocaleTimeString("fr-FR", {
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  formatVoiceDuration(seconds) {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  escapeHtml(text) {
    const div = document.createElement("div")
    div.textContent = text
    return div.innerHTML
  }

  // Méthodes pour les réponses
  replyToMessage(messageId, authorName, content) {
    this.replyToMessageId = messageId

    document.getElementById("replyToAuthor").textContent = authorName
    document.getElementById("replyToContent").textContent =
      content.length > 100 ? content.substring(0, 100) + "..." : content
    document.getElementById("replyPreview").style.display = "block"

    document.getElementById("messageInput").focus()
  }

  cancelReply() {
    this.replyToMessageId = null
    document.getElementById("replyPreview").style.display = "none"
  }

  // Méthodes pour les images
  toggleImageUpload() {
    const uploadArea = document.getElementById("imageUploadArea")
    const isVisible = uploadArea.style.display === "block"
    uploadArea.style.display = isVisible ? "none" : "block"
  }

  async handleImageUpload(file) {
    // Validation
    const allowedTypes = ["image/jpeg", "image/png", "image/gif", "image/webp"]
    if (!allowedTypes.includes(file.type)) {
      alert("Type de fichier non autorisé. Utilisez JPG, PNG, GIF ou WebP.")
      return
    }

    if (file.size > 5 * 1024 * 1024) {
      alert("Le fichier est trop volumineux (maximum 5MB)")
      return
    }

    try {
      const formData = new FormData()
      formData.append("image", file)

      const response = await fetch(`${this.baseUrl}/uploads/upload_message_image.php`, {
        method: "POST",
        body: formData,
      })

      const data = await response.json()

      if (data.success) {
        this.sendMessageViaAPI("", data.image_path)
        document.getElementById("imageUploadArea").style.display = "none"
      } else {
        alert("Erreur: " + data.message)
      }
    } catch (error) {
      console.error("Erreur upload image:", error)
      alert("Erreur lors de l'upload de l'image")
    }
  }

  async deleteMessage(messageId) {
    if (!confirm("Êtes-vous sûr de vouloir supprimer ce message ?")) {
      return
    }

    try {
      const response = await fetch(`${this.baseUrl}/delete_message.php`, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message_id: messageId,
        }),
      })

      const data = await response.json()

      if (data.success) {
        const messageElement = document.querySelector(`[data-message-id="${messageId}"]`)
        if (messageElement) {
          messageElement.classList.add("deleted")
          const bubble = messageElement.querySelector(".message-bubble")
          bubble.innerHTML = '<div><i class="fas fa-trash mr-2"></i>Ce message a été supprimé</div>'
        }
      } else {
        alert("Erreur: " + data.message)
      }
    } catch (error) {
      console.error("Erreur suppression message:", error)
      alert("Erreur lors de la suppression du message")
    }
  }
}

// Fonctions globales
function replyToMessage(messageId, authorName, content) {
  window.conversationManager.replyToMessage(messageId, authorName, content)
}

function cancelReply() {
  window.conversationManager.cancelReply()
}

function toggleImageUpload() {
  window.conversationManager.toggleImageUpload()
}

function deleteMessage(messageId) {
  window.conversationManager.deleteMessage(messageId)
}

function openImageModal(imageSrc) {
  document.getElementById("modalImage").src = imageSrc
  document.getElementById("imageModal").style.display = "flex"
}

function closeImageModal() {
  document.getElementById("imageModal").style.display = "none"
}

function toggleOptionsModal() {
  const modal = document.getElementById("optionsModal")
  if (modal.classList.contains("show")) {
    closeOptionsModal()
  } else {
    modal.classList.add("show")
  }
}

function closeOptionsModal() {
  document.getElementById("optionsModal").classList.remove("show")
}

function playVoiceMessage(voicePath, button) {
  const audio = new Audio(voicePath)
  const icon = button.querySelector("i")
  const waveform = button.parentElement.querySelector(".voice-progress")

  // Arrêter tous les autres audios
  document.querySelectorAll("audio").forEach((a) => {
    if (!a.paused) {
      a.pause()
      a.currentTime = 0
    }
  })

  // Réinitialiser tous les boutons
  document.querySelectorAll(".voice-play-button i").forEach((i) => {
    i.className = "fas fa-play"
  })

  document.querySelectorAll(".voice-progress").forEach((p) => {
    p.style.width = "0%"
  })

  if (audio.paused) {
    audio.play()
    icon.className = "fas fa-pause"

    audio.ontimeupdate = () => {
      const progress = (audio.currentTime / audio.duration) * 100
      waveform.style.width = progress + "%"
    }

    audio.onended = () => {
      icon.className = "fas fa-play"
      waveform.style.width = "0%"
    }
  } else {
    audio.pause()
    icon.className = "fas fa-play"
    waveform.style.width = "0%"
  }
}

// Initialiser le gestionnaire de conversation
window.conversationManager = new ConversationManager()
