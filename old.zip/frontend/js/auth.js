// Gestion de l'authentification
class AuthManager {
  constructor() {
    this.baseUrl = "/backend/api"
    this.init()
  }

  init() {
    // Vérifier l'authentification au chargement
    this.checkAuth()

    // Configurer les formulaires
    this.setupForms()
  }

  async checkAuth() {
    try {
      const response = await fetch(`${this.baseUrl}/auth/check-session.php`)
      const data = await response.json()

      if (data.authenticated) {
        // Utilisateur connecté
        if (window.location.pathname.includes("login.html") || window.location.pathname.includes("register.html")) {
          window.location.href = "dashboard.html"
        }
        return data.user
      } else {
        // Utilisateur non connecté
        if (
          !window.location.pathname.includes("login.html") &&
          !window.location.pathname.includes("register.html") &&
          !window.location.pathname.includes("index.html")
        ) {
          window.location.href = "login.html"
        }
        return null
      }
    } catch (error) {
      console.error("Erreur vérification auth:", error)
      return null
    }
  }

  setupForms() {
    // Formulaire de connexion
    const loginForm = document.getElementById("loginForm")
    if (loginForm) {
      loginForm.addEventListener("submit", (e) => this.handleLogin(e))
    }

    // Formulaire d'inscription
    const registerForm = document.getElementById("registerForm")
    if (registerForm) {
      registerForm.addEventListener("submit", (e) => this.handleRegister(e))
      this.setupPasswordValidation()
    }
  }

  async handleLogin(e) {
    e.preventDefault()

    const formData = new FormData(e.target)
    const loginData = {
      login: formData.get("login"),
      password: formData.get("password"),
    }

    const loginBtn = document.getElementById("loginBtn")
    const originalText = loginBtn.innerHTML

    try {
      loginBtn.disabled = true
      loginBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Connexion...'

      const response = await fetch(`${this.baseUrl}/auth/login.php`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(loginData),
      })

      const data = await response.json()

      if (data.success) {
        this.showMessage("Connexion réussie ! Redirection...", "success")
        setTimeout(() => {
          window.location.href = "dashboard.html"
        }, 1000)
      } else {
        this.showMessage(data.message || "Erreur de connexion", "error")
      }
    } catch (error) {
      console.error("Erreur login:", error)
      this.showMessage("Erreur de connexion au serveur", "error")
    } finally {
      loginBtn.disabled = false
      loginBtn.innerHTML = originalText
    }
  }

  async handleRegister(e) {
    e.preventDefault()

    const formData = new FormData(e.target)
    const registerData = {
      pseudo: formData.get("pseudo"),
      email: formData.get("email"),
      password: formData.get("password"),
      confirm_password: formData.get("confirm_password"),
    }

    // Validation côté client
    if (registerData.password !== registerData.confirm_password) {
      this.showMessage("Les mots de passe ne correspondent pas", "error")
      return
    }

    if (registerData.password.length < 6) {
      this.showMessage("Le mot de passe doit contenir au moins 6 caractères", "error")
      return
    }

    const registerBtn = document.getElementById("registerBtn")
    const originalText = registerBtn.innerHTML

    try {
      registerBtn.disabled = true
      registerBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Inscription...'

      const response = await fetch(`${this.baseUrl}/auth/register.php`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(registerData),
      })

      const data = await response.json()

      if (data.success) {
        this.showMessage("Inscription réussie ! Vous pouvez maintenant vous connecter.", "success")
        setTimeout(() => {
          window.location.href = "login.html"
        }, 2000)
      } else {
        this.showMessage(data.message || "Erreur lors de l'inscription", "error")
      }
    } catch (error) {
      console.error("Erreur register:", error)
      this.showMessage("Erreur de connexion au serveur", "error")
    } finally {
      registerBtn.disabled = false
      registerBtn.innerHTML = originalText
    }
  }

  setupPasswordValidation() {
    const password = document.getElementById("password")
    const confirmPassword = document.getElementById("confirm_password")
    const matchMessage = document.getElementById("password-match-message")

    if (!password || !confirmPassword || !matchMessage) return

    const checkPasswordMatch = () => {
      if (confirmPassword.value === "") {
        matchMessage.textContent = ""
        return
      }

      if (password.value === confirmPassword.value) {
        matchMessage.textContent = "✓ Les mots de passe correspondent"
        matchMessage.className = "mt-1 text-xs text-green-600"
      } else {
        matchMessage.textContent = "✗ Les mots de passe ne correspondent pas"
        matchMessage.className = "mt-1 text-xs text-red-600"
      }
    }

    password.addEventListener("input", checkPasswordMatch)
    confirmPassword.addEventListener("input", checkPasswordMatch)
  }

  async logout() {
    try {
      const response = await fetch(`${this.baseUrl}/auth/logout.php`, {
        method: "POST",
      })

      const data = await response.json()

      if (data.success) {
        window.location.href = "login.html"
      } else {
        console.error("Erreur logout:", data.message)
      }
    } catch (error) {
      console.error("Erreur logout:", error)
      // Rediriger quand même vers login en cas d'erreur
      window.location.href = "login.html"
    }
  }

  showMessage(message, type) {
    const messagesContainer = document.getElementById("messages")
    if (!messagesContainer) return

    const messageDiv = document.createElement("div")
    messageDiv.className = `mb-4 px-4 py-3 rounded ${
      type === "success"
        ? "bg-green-100 border border-green-400 text-green-700"
        : "bg-red-100 border border-red-400 text-red-700"
    }`

    messageDiv.innerHTML = `
            <i class="fas ${type === "success" ? "fa-check-circle" : "fa-exclamation-triangle"} mr-2"></i>
            ${message}
        `

    messagesContainer.innerHTML = ""
    messagesContainer.appendChild(messageDiv)

    // Auto-masquer après 5 secondes
    setTimeout(() => {
      if (messageDiv.parentNode) {
        messageDiv.style.transition = "opacity 0.5s"
        messageDiv.style.opacity = "0"
        setTimeout(() => {
          if (messageDiv.parentNode) {
            messageDiv.remove()
          }
        }, 500)
      }
    }, 5000)
  }
}

// Fonction globale pour logout
function logout() {
  if (window.authManager) {
    window.authManager.logout()
  } else {
    window.location.href = "login.html"
  }
}

// Initialiser le gestionnaire d'authentification
window.authManager = new AuthManager()
