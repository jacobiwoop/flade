"use client"

import  from "../frontend/js/conversation"

export default function SyntheticV0PageForDeployment() {
  return < />
}